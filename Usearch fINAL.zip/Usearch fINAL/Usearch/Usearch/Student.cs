﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Serialization;

namespace Usearch
{
    [XmlRoot(ElementName = "Student")]
    public class Student : User
    {
        [XmlAttribute(DataType = "int")]
        public int UID { get; set; }

        public override void WelcomeUser()
        {
            MessageBox.Show("Good day Student, What teacher must you visit today ?");
        }

        public Student(string firstName, string lastName, string email, string password, int uID)
            : base(firstName, lastName, email, password)
        {
            UID = uID;
        }

        public Student()
        {

        }
    }
}

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Xml.Serialization;

//namespace Usearch
//{
//    [XmlRoot(ElementName = "Student")]
//    public class Student
//    {
//        [XmlAttribute(DataType = "string")]
//        public string SFirstName { get; set; }

//        [XmlAttribute(DataType = "string")]
//        public string SLastName { get; set; }

//        [XmlAttribute(DataType = "string")]
//        public string SEmail { get; set; }

//        [XmlAttribute(DataType = "string")]
//        public string SPassword { get; set; }

//        [XmlAttribute(DataType = "int")]
//        public int UID { get; set; }

//        public Student(string sFirstName, string sLastName, string sEmail, string sPassword, int uID)
//        {
//            SFirstName = sFirstName;
//            SLastName = sLastName;
//            SEmail = sEmail;
//            SPassword = sPassword;
//            UID = uID;
//        }

//        public Student()
//        {

//        }

//    }
//}
