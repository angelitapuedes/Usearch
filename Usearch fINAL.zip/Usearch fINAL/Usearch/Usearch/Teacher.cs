﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Serialization;

namespace Usearch
{
    [XmlRoot(ElementName = "Teacher")]
    public class Teacher : User
    {

        [XmlAttribute(DataType = "string")]
        public string TAvailable { get; set; }

        [XmlAttribute(DataType = "string")]
        public string ImagePath { get; set; }

        [XmlAttribute(DataType = "string")]
        public string FullName { get; set; }

        [XmlAttribute(DataType = "string")]
        public string Office { get; set; }

        [XmlAttribute(DataType = "string")]
        public string PhoneNumber { get; set; }

        [XmlAttribute(DataType = "string")]
        public string Research { get; set; }

        public override void WelcomeUser()
        {
            MessageBox.Show("Good Day Professor, thank you for being here today!!!");
        }


        public Teacher(string firstName, string lastName, string email, string password, string available, string imagePath, string fullName, string office, string phoneNumber, string research)
            : base(firstName, lastName, email, password)
        {

            TAvailable = available;
            ImagePath = imagePath;
            FullName = fullName;
            Office = office;
            PhoneNumber = phoneNumber;
            Research = research;
        }

        public Teacher()
        {

        }

        //public override string ToString()
        //    {
        //        return $"{TFirstName} {TLastName}";
        //    }
    }
}

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Xml.Serialization;

//namespace Usearch
//{
//    [XmlRoot(ElementName = "Teacher")]
//    public class Teacher
//    {
//            [XmlAttribute(DataType = "string")]
//            public string TFirstName { get; set; }

//            [XmlAttribute(DataType = "string")]
//            public string TLastName { get; set; }

//            [XmlAttribute(DataType = "string")]
//            public string TEmail { get; set; }

//            [XmlAttribute(DataType = "string")]
//            public string TPassword { get; set; }

//            [XmlAttribute(DataType = "string")]
//            public string TAvailable { get; set; }

//            [XmlAttribute(DataType = "string")]
//            public string ImagePath { get; set; }

//            [XmlAttribute(DataType = "string")]
//            public string FullName { get; set; }

//            [XmlAttribute(DataType = "string")]
//            public string Office { get; set; }

//            [XmlAttribute(DataType = "string")]
//            public string PhoneNumber { get; set; }

//            [XmlAttribute(DataType = "string")]
//            public string Research { get; set; }

//        public Teacher(string firstName, string lastName, string email, string password, string available, string imagePath, string fullName, string office, string phoneNumber, string research)
//        {
//            TFirstName = firstName;
//            TLastName = lastName;
//            TEmail = email;
//            TPassword = password;
//            TAvailable = available;
//            ImagePath = imagePath;
//            FullName = fullName;
//            Office = office;
//            PhoneNumber = phoneNumber;
//            Research = research;
//        }

//        public Teacher()
//        {

//        }

//        //public override string ToString()
//        //    {
//        //        return $"{TFirstName} {TLastName}";
//        //    }
//        }
//    }
