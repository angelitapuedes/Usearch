﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace Usearch
{
    /// <summary>
    /// Interaction logic for StudentLogin.xaml
    /// This file is grabbing the information that  the student enters for logging in
    /// </summary>
    public partial class StudentLogin : Window
    {
        //List to put students in from file
        ObservableCollection<Student> studentCollection = new ObservableCollection<Student>();
        XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Student>));

        public StudentLogin()
        {
            InitializeComponent();
            try
            {
                ReadStudentsFromMemory();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to read xml file * ********", ex.InnerException);
                MessageBox.Show($"Unable to read xml file\nInner Exception:{ex.InnerException.Message}");
            }
        }
        public StudentLogin(ObservableCollection<Student> secondRound)
        {
            //In case we need this, this is the updated list of the  email user with the ne
            //MessageBox.Show("Hi");
            studentCollection = secondRound;

            InitializeComponent();
            try
            {
                ReadStudentsFromMemory();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to read xml file * ********", ex.InnerException);
                MessageBox.Show($"Unable to read xml file\nInner Exception:{ex.InnerException.Message}");
            }

        }

        private void ReadStudentsFromMemory()
        {
            //name of file to read
            string path = "student2.xml";

            if (File.Exists(path))
            {
                using (FileStream ReadStream = new FileStream(path, FileMode.Open, FileAccess.Read))
                {
                    studentCollection = serializer.Deserialize(ReadStream) as ObservableCollection<Student>;//breaking apart into .xmal format
                }
            }
        }

        //This is a button that leads to the Add student window to create a new student
        private void CreateNewStudent(object sender, RoutedEventArgs e)
        {
            AddStudent aS = new AddStudent();
            aS.ShowDialog();
            this.Close();      
        }

        private void LoginNow(object sender, RoutedEventArgs e)
        {
            if(ValidateLogin(Emaillogin.Text))
            {
                SearchTeacherMain sT = new SearchTeacherMain();
                sT.ShowDialog();
                this.Close();
            } 
        }

        //Validations for login information
        private bool ValidateLogin(string tester)
        {
            foreach (Student s in studentCollection)
            {
                if (Emaillogin.Text == s.Email && Passwordlogin.Password == s.Password)
                {
                    if (s.Password == "Bull4Life")
                    {
                        //this.Close();
                        MessageBox.Show("Navigating to change password page");
                        MakeBullNewPassword mnp = new MakeBullNewPassword(Emaillogin.Text,studentCollection);
                        mnp.ShowDialog();
                        ReadStudentsFromMemory();
                      //  this.Close();
                        return true;
                    }
                    else
                    {
                        return true;
                    }
                }
            }
            Emaillogin.Background = Brushes.Coral;
            Passwordlogin.Background = Brushes.Coral;
            MessageBox.Show("Email or password is incorrect");
            ClearAll();
            return false;
        }

        private void TextFieldChanged(object sender, TextChangedEventArgs e)
        {
            TextBox tb = (sender as TextBox);
            if (tb.Name == Emaillogin.Name)
            {
                Emaillogin.Background = Brushes.White;
            }

            if (tb.Name == Passwordlogin.Name)
            {
                Passwordlogin.Background = Brushes.White;
            }
        }

        void ClearAll()
        {
            Emaillogin.Clear();
            Passwordlogin.Clear();
            Emaillogin.Background = Brushes.White;
            Passwordlogin.Background = Brushes.White;
        }

        private void ResetPasswordOrEmail(object sender, RoutedEventArgs e)
        {
            //go to a new window and have the user enter his name, and lastname and email, then in a
            //for loop check the user with those things and then do this email thing and use email.text.

            //Need to write new email login bull4life
            
            ResetWindow rw = new ResetWindow();
            rw.ShowDialog();
            this.Close();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}

