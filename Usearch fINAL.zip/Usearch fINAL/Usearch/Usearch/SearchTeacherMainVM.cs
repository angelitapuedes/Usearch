﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Xml.Serialization;

namespace Usearch
{
    public class SearchTeacherMainVM:INotifyPropertyChanged
    {
        public SearchTeacherVM sd { get; set; }

        private Teacher _selectedTeacher;
        public Teacher SelectedTeacher
        {
            get { return _selectedTeacher; }
            set
            {
                _selectedTeacher = value;
                PropertyChanged(this, new PropertyChangedEventArgs("SelectedTeacher"));
            }
        }

        private ObservableCollection<Teacher> _teacherCollection;
        public ObservableCollection<Teacher> TeacherCollection
        {
            get { return _teacherCollection; }
            set
            {
                _teacherCollection = value;
                PropertyChanged(this, new PropertyChangedEventArgs("TeacherCollection"));
            }
        }

        // ObservableCollection<Teacher> teacherCollection = new ObservableCollection<Teacher>();
        XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Teacher>));

        public SearchTeacherMainVM()
        {
            ReadTeacherFromMemory();
           
        }
        private void ReadTeacherFromMemory()
        {
            //name of file to read
            string path = "teacher.xml";
            TeacherCollection = new ObservableCollection<Teacher>();
            if (File.Exists(path))
            {
                using (FileStream ReadStream = new FileStream(path, FileMode.Open, FileAccess.Read))
                {
                    TeacherCollection = serializer.Deserialize(ReadStream) as ObservableCollection<Teacher>;
                }
            }
        }

        //private void TeacherChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    //addon.Visibility = Visibility.Visible;
        //    SearchTeacherMain stm = new SearchTeacherMain();
        //    SearchDisplay sc = new SearchDisplay();
            
        //    stm.ShowInfo.Visibility = Visibility.Visible;
        //    SelectedTeacher = stm.TeacherCombo.SelectedItem as Teacher;
        //    stm.Panel.Visibility = Visibility.Visible;
        //    sc.Research.Visibility = Visibility.Visible;
            
        //    if (_selectedTeacher.TAvailable == "Busy")
        //    {
        //        stm.Status.Background = Brushes.Red;
        //        stm.Status.Visibility = Visibility.Visible;
        //    }
        //    else
        //    {
        //        stm.Status.Background = Brushes.Green;
        //        stm.Status.Visibility = Visibility.Visible;
        //    }
        //}

        public event PropertyChangedEventHandler PropertyChanged = delegate { };

    }
}
