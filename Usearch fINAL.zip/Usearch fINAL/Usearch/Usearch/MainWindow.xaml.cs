﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Usearch
{
    /// <summary>
    /// *****************************************
    /// Interaction logic for MainWindow.xaml   *
    /// This is our proganm USearch where a USF *
    /// student can search to see               *
    /// if there professor is available for     *   
    /// office hours or not. When the time      *
    /// that the student decides he or she needs* 
    /// help In this window the user chooses    *
    /// whether or not they are a student or    *
    /// teacher                                 *
    /// *****************************************
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent(); //new MainWindowVM();
        
            //InitializeComponent();
        }

        private void ChoiceStudent(object sender, RoutedEventArgs e)
        {
            StudentLogin sL = new StudentLogin();
            sL.ShowDialog();
            //this.Close();
        }

        private void ChoiceTeacher(object sender, RoutedEventArgs e)
        {
            TeacherLogin tL = new TeacherLogin();
            tL.ShowDialog();
        }
    }
}
