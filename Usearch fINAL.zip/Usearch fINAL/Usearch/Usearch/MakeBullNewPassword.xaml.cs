﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace Usearch
{
    /// <summary>
    /// Interaction logic for MakeBullNewPassword.xaml
    /// </summary>
    public partial class MakeBullNewPassword : Window
    {
        Student tempPasswordguy = new Student();
        public List<Student> LT = new List<Student>();
        XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Student>));
        XmlSerializer xmler = new XmlSerializer(typeof(List<Student>));
        ObservableCollection<Student> UpdatedList = new ObservableCollection<Student>();
        //string word = "Bull4Life";
        string changeEmail;

        public MakeBullNewPassword(String email, ObservableCollection<Student> temp)
        {
            InitializeComponent();
            //tempPasswordguy = NewPassWord;
            this.LT = temp.ToList();
            this.UpdatedList = temp;
            changeEmail = email;
        }

        private void SubmitPassword(object sender, RoutedEventArgs e)
        {
            List<Student> tempToFindS = UpdatedList.Where(x => x.Email == changeEmail).ToList();
            foreach (Student s in tempToFindS)
            {
                if (changeEmail == s.Email)
                {
                   // s.SPassword = PasswordUpdate.Text;
                    tempPasswordguy = s;
                   // MessageBox.Show("New password set");
                }
            }
            LT.RemoveAll(x => x.Email == changeEmail);
            tempPasswordguy.Password = PasswordUpdate.Text;
            LT.Add(tempPasswordguy);

            string path = "student2.xml";

            if (File.Exists(path) && UpdatedList.Count() == 0)
            {
                File.Delete(path);
            }
            else
            {
                using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.ReadWrite))
                {
                    xmler.Serialize(fs, LT);
                }
            }
            MessageBox.Show("Password Updated");
            this.Close();
        }
    }
}
