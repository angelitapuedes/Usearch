﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace Usearch
{
    /// <summary>
    /// Interaction logic for TeacherLogin.xaml
    ///  This file is grabbing the information that  the teacher enters for logging in
    /// </summary>
    public partial class TeacherLogin : Window
    {
        ObservableCollection<Teacher> teacherCollection = new ObservableCollection<Teacher>();
        XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Teacher>));
        public TeacherLogin()
        {
            InitializeComponent();
            try
            {
                ReadTeacherFromMemory();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to read xml file * ********", ex.InnerException);
                MessageBox.Show($"Unable to read xml file\nInner Exception:{ex.InnerException.Message}");
            }
        }

        private void ReadTeacherFromMemory()
        {
            //name of file to read
            string path = "teacher.xml";

            if (File.Exists(path))
            {
                using (FileStream ReadStream = new FileStream(path, FileMode.Open, FileAccess.Read))
                {
                    teacherCollection = serializer.Deserialize(ReadStream) as ObservableCollection<Teacher>;//breaking apart into .xmal format
                }
            }
        }

        private void LoginNow(object sender, RoutedEventArgs e)
        {
            ValidateLogin(Emaillogin.Text);
        }

        //validation login
        private bool ValidateLogin(string tester)
        {

            Teacher teacherUser = teacherCollection.FirstOrDefault(x => x.Email == Emaillogin.Text && x.Password == Passwordlogin.Password);
            if (teacherUser==null)
            {
                Emaillogin.Background = Brushes.Coral;
                Passwordlogin.Background = Brushes.Coral;
                MessageBox.Show("Email or password is incorrect");
                ClearAll();
                return false;
            }
            string test = Emaillogin.Text;
            TeacherStatus tS = new TeacherStatus(test, teacherUser, teacherCollection);
            tS.ShowDialog();
            this.Close();
            return true;
        }
      
        private void TextFieldChanged(object sender, TextChangedEventArgs e)
        {
            TextBox tb = (sender as TextBox);
            if (tb.Name == Emaillogin.Name)
            {
                Emaillogin.Background = Brushes.White;
            }

            if (tb.Name == Passwordlogin.Name)
            {
                Passwordlogin.Background = Brushes.White;
            }
        }

        void ClearAll()
        {
            Emaillogin.Clear();
            Passwordlogin.Clear();
            Passwordlogin.Background = Brushes.White;
            Emaillogin.Background = Brushes.White;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
