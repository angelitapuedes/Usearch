﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace Usearch
{
    /// <summary>
    /***********************************************************************
     * In this window we are adding a student into the file. When the user *
     * is new to using this program he or she will need to create an       *
     * account in this addstudent window. There will be a file that we will* 
     * read in to check if they do exist and then if not we will add there *
     * information that they entered in the xmal window using the text     *
     * boxes add that information back into an updated file of students   *
     **********************************************************************/
    /// </summary>
   
    public partial class AddStudent : Window
    {
        //List that will hold student information from the file holding student information
        ObservableCollection<Student> studentCollection = new ObservableCollection<Student>();

        //serialize stuff from the file to read and write to xml file
        XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Student>));

        //In this parameter is just to throw an exception
        public AddStudent()
        {
            InitializeComponent();
            try
            {
                ReadStudentsFromMemory();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to read xml file * ********", ex.InnerException);
                MessageBox.Show($"Unable to read xml file\nInner Exception:{ex.InnerException.Message}");
            }
        }
        //Reading from the Filw
        private void ReadStudentsFromMemory()
        {
            //name of file to read
            string path = "student2.xml";

            if (File.Exists(path))
            {
                using (FileStream ReadStream = new FileStream(path, FileMode.Open, FileAccess.Read))
                {
                    studentCollection = serializer.Deserialize(ReadStream) as ObservableCollection<Student>;//breaking apart into .xmal format
                }
            }
        }

        //Create account Button to make a new student
        private void CreateStudent(object sender, RoutedEventArgs e)//Adding student with the submit button in MainXmal
        {
            //Adding the student information to an object s of the student class if validations are verified
            string path = "student2.xml";
            if (Validate())
            {
                Student s = new Student(FirstNameEntry.Text, LastNameEntry.Text, EmailNameEntry.Text+"@mail.usf.edu", PasswordBox.Password, int.Parse(UIDEntry.Text));
                studentCollection.Add(s);
                if (studentCollection.Count == 0 && File.Exists(path))
                {
                    File.Delete(path);
                }
                else
                {
                    using (FileStream ws = new FileStream(path, FileMode.Create, FileAccess.ReadWrite))
                    {
                        serializer.Serialize(ws, studentCollection);
                    }
                }
                MessageBox.Show("Account Created", "Success!!");
                this.Close();
            }
        }

        //Validate entries
        private bool Validate()
        {
            bool firstNameValid;
            bool lastNameValid;
            bool UIDValid;
            bool emailValid;
            bool password;

            firstNameValid = string.IsNullOrWhiteSpace(FirstNameEntry.Text) ? false : SValidateForLetters(FirstNameEntry.Text);
            FirstNameEntry.Background = firstNameValid ? Brushes.White : Brushes.Coral;

            lastNameValid = string.IsNullOrWhiteSpace(LastNameEntry.Text) ? false : SValidateForLetters(LastNameEntry.Text);
            LastNameEntry.Background = lastNameValid ? Brushes.White : Brushes.Coral;

            //UIDValid = SValidateUNUM(UIDEntry.Text);
            //UIDEntry.Background = UIDValid ? Brushes.White : Brushes.Coral;

            UIDValid = string.IsNullOrWhiteSpace(UIDEntry.Text) ? false : ValidateForDigits(UIDEntry.Text);
            UIDEntry.Background = UIDValid ? Brushes.White : Brushes.Coral;
            if (UIDValid == false)
            {
                MessageBox.Show("UID ERROR");
            }
            else
            {
                SValidateUNUM(UIDEntry.Text);
            }

            emailValid = SValidateEmail(EmailNameEntry.Text);

            if (string.IsNullOrWhiteSpace(PasswordBox.Password)||PasswordBox.Password.Length < 8 ||PasswordBox.Password.Length>15)
            {
                password = false;
                PasswordBox.Clear();
                MessageBox.Show("Password needs to be 8 - 15 characters and can include letters, numbers and symbols.");
            }
            else
            {
                PasswordBox.Background = Brushes.White;
                password = true;
            }
            return firstNameValid && lastNameValid && UIDValid && emailValid && password;
        }

        private bool SValidateEmail(string text)
        {
            foreach (Student s in studentCollection)
            {
                if (EmailNameEntry.Text == s.Email || string.IsNullOrWhiteSpace(EmailNameEntry.Text))
                {
                    EmailNameEntry.Clear();
                    MessageBox.Show("Email already exists or left blank");

                    return false;
                }
            }
            return true;
        }

        //validation if the uid already exist
        private bool SValidateUNUM(string text, int max =8)
        {
            foreach (Student s in studentCollection)
            {
                if ( s.UID == int.Parse(UIDEntry.Text))
                {
                    UIDEntry.Clear();
                    MessageBox.Show("UID already exists or left blank");
                    return false;
                }
             
                }
            return text.Length == max && text.Where(x => char.IsDigit(x)).Count() == text.Length;
        }

        private bool SValidateForLetters(string tester)
        {
            return tester.Where(x => char.IsLetter(x)).Count() == tester.Length;
        }

        private bool ValidateForDigits(string tester, int max = 8)
        {
            return tester.Length == max && tester.Where(x => char.IsDigit(x)).Count() == tester.Length;
        }
        private void TextFieldChanged(object sender, TextChangedEventArgs e)
        {
            TextBox tb = (sender as TextBox);
            if (tb.Name == UIDEntry.Name)
            {
                UIDEntry.Background = Brushes.White;
            }

            if (tb.Name == FirstNameEntry.Name)
            {
                FirstNameEntry.Background = Brushes.White;
            }

            if (tb.Name == LastNameEntry.Name)
            {
                LastNameEntry.Background = Brushes.White;
            }

            if (tb.Name == PasswordBox.Name)
            {
                PasswordBox.Background = Brushes.White;
            }

            if (tb.Name == EmailNameEntry.Name)
            {
                EmailNameEntry.Background = Brushes.White;
            }
        }
        //Writing the file
        private void WriteStudentFile()
        {
            string path = "student2.xml";
            if (studentCollection.Count == 0 && File.Exists(path))
            {
                File.Delete(path);
            }
            else
            {
                using (FileStream filestream = new FileStream(path, FileMode.Create, FileAccess.ReadWrite))
                {
                    serializer.Serialize(filestream, studentCollection);
                }
                MessageBox.Show("All students have written to file", "Success!!");
            }
        }
    }
}
