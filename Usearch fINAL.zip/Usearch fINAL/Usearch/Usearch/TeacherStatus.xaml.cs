﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace Usearch
{
    /// <summary>
    /// Interaction logic for TeacherStatus.xaml
    /// This is a window to check the status of a teacher, the student will login
    /// This is the window where the teacher will update his or her status using a combo box for availability status
    /// </summary>
    public partial class TeacherStatus : Window
    {
        ObservableCollection<string> StatusOption = new ObservableCollection<string>() { "Available", "Busy" };
        public List<Teacher> LT = new List<Teacher>();
        string Email;

        ObservableCollection<Teacher> TeacherUsers = new ObservableCollection<Teacher>();
        Teacher t = new Teacher();

        XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Teacher>));
        XmlSerializer xmler = new XmlSerializer(typeof(List<Teacher>));


        public TeacherStatus(string email, Teacher test, ObservableCollection<Teacher> collection)
        {
            InitializeComponent();
            this.t = test;
            this.Email = email;
            this.LT = collection.ToList();
            this.TeacherUsers = collection;
            TeacherCombo.ItemsSource = StatusOption;
        }

        private void StatusChange(object sender, RoutedEventArgs e)
        {
            if (TeacherCombo.SelectionBoxItem.ToString() == "")
            {
                MessageBox.Show("Error: Select Availability");
            }
            else
            {
                //updating teacher by removing them from the list and adding it back into the list
                LT.RemoveAll(x => x.Email == Email);
                t.TAvailable = TeacherCombo.SelectedItem.ToString();
                LT.Add(t);


                string path = "teacher.xml";

                if (File.Exists(path) && TeacherUsers.Count() == 0)
                {
                    File.Delete(path);
                }
                else
                {
                    using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.ReadWrite))
                    {
                        xmler.Serialize(fs, LT);
                    }
                }
                MessageBox.Show("Status Updated");
            }
            ClearAll();
        }

        private void NameChange(object sender, RoutedEventArgs e)
        {
            bool firstNameValid = string.IsNullOrWhiteSpace(UpdateFN.Text) ? false : ValidateForLetters(UpdateFN.Text);
            UpdateFN.Background = firstNameValid ? Brushes.White : Brushes.Coral;

            bool lastNameValid = string.IsNullOrWhiteSpace(UpdateLN.Text) ? false : ValidateForLetters(UpdateLN.Text);
            UpdateLN.Background = lastNameValid ? Brushes.White : Brushes.Coral;

            if (!firstNameValid || !lastNameValid)
            {
                MessageBox.Show("Please fill out both name entries with letters only");
                //ClearAll();
            }
            else
            {
                LT.RemoveAll(x => x.Email == Email);
                t.FirstName = UpdateFN.Text;
                t.LastName = UpdateLN.Text;
                t.FullName = UpdateFN.Text+" "+ UpdateLN.Text;
                LT.Add(t);

                //LT.RemoveAll(x => x.TEmail == Email);
                //t.TAvailable = TeacherCombo.SelectedItem.ToString();
                //LT.Add(t);

                string path = "teacher.xml";

                if (File.Exists(path) && TeacherUsers.Count() == 0)
                {
                    File.Delete(path);
                }
                else
                {
                    using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.ReadWrite))
                    {
                        xmler.Serialize(fs, LT);
                    }
                }
                MessageBox.Show("Name Updated");
            }
            ClearAll();

        }

        private void OfficeChange(object sender, RoutedEventArgs e)
        {
            bool officeNameValid = string.IsNullOrWhiteSpace(UpdateOffice.Text) ? false : true;
            UpdateOffice.Background = officeNameValid ? Brushes.White : Brushes.Coral;

            if (string.IsNullOrWhiteSpace(UpdateOffice.Text))
            {
                officeNameValid = false;
                UpdateOffice.Background = Brushes.Coral;
               // MessageBox.Show("Please dont leave this blank");
            }
            else
            {
                UpdateOffice.Background = Brushes.White;
               officeNameValid = true;
            }

            if (!officeNameValid)
            {
                MessageBox.Show("Please don't leave the entry box blank");
               // ClearAll();
            }
            else
            {
                LT.RemoveAll(x => x.Email == Email);
                t.Office = UpdateOffice.Text;
                LT.Add(t);

                string path = "teacher.xml";

                if (File.Exists(path) && TeacherUsers.Count() == 0)
                {
                    File.Delete(path);
                }
                else
                {
                    using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.ReadWrite))
                    {
                        xmler.Serialize(fs, LT);
                    }
                }
                MessageBox.Show("Office Updated");
            }
            ClearAll();
        }

        private bool ValidateForLetters(string tester)
        {
            return tester.Where(x => char.IsLetter(x)).Count() == tester.Length;//making sure there are no tester=characters, numbers, witespace
        }

        private void ClearAll()
        {
            UpdateFN.Clear();
            UpdateLN.Clear();
            UpdateOffice.Clear();
            UpdateFN.Background = Brushes.White;
            UpdateLN.Background = Brushes.White;
            UpdateOffice.Background = Brushes.White;
        }
    }
}