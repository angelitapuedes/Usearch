﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Xml.Serialization;

namespace Usearch
{
    public class SearchTeacherVM:INotifyPropertyChanged
    {
        public SearchTeacherMainVM sd { get; set; }
        private Teacher _selectedTeacher;
        

        public Teacher SelectedTeacher
        {
            get { return _selectedTeacher; }
            set
            {
                _selectedTeacher = value;
                PropertyChanged(this, new PropertyChangedEventArgs("SelectedTeacher"));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public SearchTeacherVM()
        {
            
        }
    }  
    }
