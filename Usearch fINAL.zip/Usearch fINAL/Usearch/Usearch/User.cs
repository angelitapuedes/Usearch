﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Serialization;

namespace Usearch
{
    public abstract class Welcome : User
    {
        public abstract override void WelcomeUser();
    }

    [XmlRoot(ElementName = "User")]
    public class User
    {
        [XmlAttribute(DataType = "string")]
        public string FirstName { get; set; }

        [XmlAttribute(DataType = "string")]
        public string LastName { get; set; }

        [XmlAttribute(DataType = "string")]
        public string Email { get; set; }

        [XmlAttribute(DataType = "string")]
        public string Password { get; set; }

        public virtual void WelcomeUser()
        {
            //MessageBox.Show("Hey guys Welcome to the Application");
        }

        public User(string firstName, string lastName, string email, string password)
        {
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            Password = password;
        }

        public User()
        {

        }
    }
}
