﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace Usearch
{
    /// <summary>
    /// Interaction logic for SearchTeacher.xaml
    /// In this window the student is searching for the specific teacher they need availability information on
    /// </summary>
    public partial class SearchTeacherMain
    {
        private Teacher _selectedTeacher;
        public Teacher SelectedTeacher
        {
            get { return _selectedTeacher; }
            set
            {
                _selectedTeacher = value;
                PropertyChanged(this, new PropertyChangedEventArgs("SelectedTeacher"));
            }
        }
        public SearchTeacherMain()
        {
            InitializeComponent();
            SearchTeacherMainVM mvm = new SearchTeacherMainVM();
            DataContext = mvm;
            Panel.Visibility = Visibility.Hidden;
        }

        private void Logout(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void TeacherChanged(object sender, SelectionChangedEventArgs e)
        {
            ShowInfo.Visibility = Visibility.Visible;
            SelectedTeacher = TeacherCombo.SelectedItem as Teacher;
            Panel.Visibility = Visibility.Visible;
            //Research.Visibility = Visibility.Visible;

            if (_selectedTeacher.TAvailable == "Busy")
            {
                Status.Background = Brushes.Red;
                Status.Visibility = Visibility.Visible;
            }
            else
            {
                Status.Background = Brushes.Green;
                Status.Visibility = Visibility.Visible;
            }
        }
        public event PropertyChangedEventHandler PropertyChanged = delegate { };
    }
}
