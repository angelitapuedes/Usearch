﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Serialization;
namespace Usearch
{
    public partial class ResetWindow : Window
    {
        ObservableCollection<Student> ResetVerifier = new ObservableCollection<Student>();
        List<Student> tempList = new List<Student>();
        XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Student>));
        Student s = new Student();

        public ResetWindow()
        {
            InitializeComponent();
            
            try
            {
                ReadStudentsFromMemory();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unable to read xml file * ********", ex.InnerException);
                MessageBox.Show($"Unable to read xml file\nInner Exception:{ex.InnerException.Message}");
            }
        }
        private void ReadStudentsFromMemory()
        {
            //name of file to read
            string path = "student2.xml";

            if (File.Exists(path))
            {
                using (FileStream ReadStream = new FileStream(path, FileMode.Open, FileAccess.Read))
                {
                    ResetVerifier = serializer.Deserialize(ReadStream) as ObservableCollection<Student>;//breaking apart into .xmal format
                }
            }
        }

  
        private bool ValidateLogin(string tester)
        {
            foreach (Student s in ResetVerifier)
            {
                if (EmailNameEntry.Text == s.Email)
                {
                    return true;
                }
            }
           // EmailNameEntry.Background = Brushes.Coral;
            MessageBox.Show("This email is not associated with an account or space left blank");
            ClearAll();
            return false;
        }

        private void ResetPassword_Click(object sender, RoutedEventArgs e)
        {
            //ReadStudentsFromMemory();
            if (ValidateLogin(EmailNameEntry.Text))
            {
                SmtpClient client = new SmtpClient("smtp.gmail.com");
                client.Port = 587;
                client.EnableSsl = true;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Timeout = 10000;//the first parameter 
                                       //is the account sending the email, the second is the password for that account
                client.Credentials = new System.Net.NetworkCredential("psalmsjc1@gmail.com", "//angelito2020JC");
                MailMessage mail = new MailMessage();
                //parameter is the account send ing the
                mail.From = new MailAddress("psalmsjc1@gmail.com");//FRom
                mail.To.Add(EmailNameEntry.Text);
                mail.Subject = "Verify Your Account";


                mail.Body = $"Welcome {EmailNameEntry.Text}, here is your temporary password, Bull4Life you" +
                $" must verify your email by clicking the link";
                mail.BodyEncoding = Encoding.UTF8;
                client.Send(mail);
                MessageBox.Show("Email sent");
                //The end and the email has been sent
                //The is assigning an e=object that carries the email of the user and
                //The list tempToFindS will carry soley the object of that email user
                List<Student> tempToFindS = ResetVerifier.Where(x => x.Email == EmailNameEntry.Text.ToString()).ToList();
                //This loop will assign object StudentToEdit to the emailuserin the list tempToFundS, a copy of that person
                //Object of mail user info
                foreach (Student StudentToEdit in tempToFindS)
                {
                    //if this objecrt email mathes the email entered as a double check
                    if (EmailNameEntry.Text == StudentToEdit.Email)
                    {
                        //We remove that person form the Master List ResetVerifier
                        ResetVerifier.Remove(StudentToEdit);
                        //In this loop a new object newPerson will look into list tempToFindS
                        foreach (Student newPerson in tempToFindS)
                        {
                            //Then we will assign that object the info that is in the tempToFindS and also 
                            //Modify the password to BUll4Life
                            newPerson.Password = "Bull4Life";
                            //Adding to the list
                            ResetVerifier.Add(newPerson);
                            //Writing this person to the list which just modified the users password
                            WriteStudentFile();
                        }
                        
                        //logging into login window for the user to log in for 2nd time, passing the list
                        StudentLogin LoginSecondTime = new StudentLogin(ResetVerifier);
                        LoginSecondTime.ShowDialog();
                        this.Close();

                    }
                }
            }
        }

        private void WriteStudentFile()
        {
            string path = "student2.xml";
            if (ResetVerifier.Count == 0 && File.Exists(path))
            {
                File.Delete(path);
            }
            else
            {
                using (FileStream filestream = new FileStream(path, FileMode.Create, FileAccess.ReadWrite))
                {
                    serializer.Serialize(filestream, ResetVerifier);
                }
               // MessageBox.Show("All students have written to file", "Success!!");
            }
        }
        private void ClearAll()
        {
            EmailNameEntry.Clear();
        }

    }
}






